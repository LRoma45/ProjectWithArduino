public class ClasseDati 
{
    int temperatura, umidità;
    String data;
    
    ClasseDati(int temperatura, int umidità, String data)
    {
        this.temperatura=temperatura;
        this.umidità=umidità;
        this.data=data;
    }
}

